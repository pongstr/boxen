require 'spec_helper'

#describe 'sqldeveloper' do
#  it do
#    should contain_package('SQLdeveloper').with({
#      :source   => 'http://192.168.21.151/sqldeveloper-4.1.1.19.59-macosx.app.zip',
#      :provider => 'compressed_app'
#    })
#  end
#end
