require 'spec_helper'

#describe 'winzip' do
#  it do
#    should contain_package('Winzip').with({
#      :source   => 'http://192.168.21.151/winzipmacedition40.dmg',
#      :provider => 'appdmg'
#    })
#  end
#end
