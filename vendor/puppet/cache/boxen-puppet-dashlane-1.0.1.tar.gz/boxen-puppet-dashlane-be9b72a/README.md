# Papers Puppet Module for Boxen

## Usage

```puppet
include papers
```

## Required Puppet Modules

* boxen

