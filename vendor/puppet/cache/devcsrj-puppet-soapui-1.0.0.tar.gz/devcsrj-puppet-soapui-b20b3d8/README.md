# SoapUI Puppet Module for Boxen

## Usage

```puppet
include soapui
```

## Required Puppet Modules

* boxen

