# SQL Power Architect Puppet Module for Boxen

## Usage

```puppet
include sqlpowerarchitect
```

## Required Puppet Modules

* boxen

