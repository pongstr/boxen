require 'spec_helper'

#describe 'keynote' do
#  it do
#    should contain_package('Keynote').with({
#      :source   => 'http://192.168.21.151/Keynote.zip',
#      :provider => 'compressed_app'
#    })
#  end
#end
