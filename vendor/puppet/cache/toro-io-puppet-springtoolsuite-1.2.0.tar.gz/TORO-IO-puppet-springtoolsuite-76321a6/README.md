
# Spring Tool Suite Puppet Module for Boxen

Installs the [Spring Tool Suite](http://www.springsource.org/sts) 

## Usage

```puppet
include springtoolsuite
```
