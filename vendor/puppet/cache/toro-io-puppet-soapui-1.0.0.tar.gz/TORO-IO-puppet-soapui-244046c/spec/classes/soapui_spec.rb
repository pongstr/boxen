require 'spec_helper'

describe 'soapui' do

  it do
    should contain_package('SoapUI').with({
      :provider => 'appdmg',
      :source   => 'http://nchc.dl.sourceforge.net/project/soapui/soapui/5.2.0/SoapUI-5.2.0.dmg'
    })
  end
end
